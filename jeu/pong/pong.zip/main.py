import pygame
from niv1 import*
from level import niveau

class Game:
	def __init__(self):
		pygame.init()
		self.state = 0
		self.ecran = pygame.display.set_mode((largeur, longueur))
		pygame.display.set_caption('test_jeu')
		# self.font1 = pygame.font.SysFont("minecraft/Minecraft.ttf", 50)
		# self.img1 = self.font1.render(str(niveau.score_j1), True, 'White')
		# self.font2 = pygame.font.SysFont("minecraft/Minecraft.ttf", 50)
		# self.img2 = self.font2.render(str(niveau.score_j2), True, 'White')
		self.clk = pygame.time.Clock()
		self.niv = niveau(niv1, self.ecran)
		self.touche_j1 = [False, False]
		self.touche_j2 = [False, False]
		self.continuer = True

	# def affiche_score(self):
	# 	self.ecran.blit(self.img1, (largeur/4, 50))
	# 	self.ecran.blit(self.img2, (largeur - largeur/4, 50))

	def run(self):
		while(self.continuer):
			for event in pygame.event.get():
				if event.type == pygame.KEYDOWN:
					if event.key == pygame.K_ESCAPE:
						self.continuer = False
					if event.key == pygame.K_z:
						self.touche_j1[0] = True
					if event.key == pygame.K_s:
						self.touche_j1[1] = True
					if event.key == pygame.K_o:
						self.touche_j2[0] = True
					if event.key == pygame.K_l:
						self.touche_j2[1] = True
				if event.type == pygame.KEYUP:
					if event.key == pygame.K_z:
						self.touche_j1[0] = False
					if event.key == pygame.K_s:
						self.touche_j1[1] = False
					if event.key == pygame.K_o:
						self.touche_j2[0] = False
					if event.key == pygame.K_l:
						self.touche_j2[1] = False
				if event.type == pygame.QUIT:
					self.continuer = False
			self.ecran.fill('Black')
			a = self.niv.run(self.touche_j1, self.touche_j2)
			self.clk.tick(60)
			pygame.display.update()
		pygame.quit()

game = Game()
game.run()