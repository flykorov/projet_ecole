:- module(has_gold, [updateHasGold/4]).

% Predicats pour le gold :
goldMaj(Certain_Fluents, New_Certain_Fluents) :-
    New_Certain_Fluents = Certain_Fluents.put(has_gold, true).

updateHasGold(grab, [], Certain_Fluents, Certain_Fluents). % Si liste vide on fait rien
updateHasGold(grab, Percepts ,Certain_Fluents, New_Certain_Fluents) :-
    (member(glitter, Percepts) ->
        goldMaj(Certain_Fluents, New_Certain_Fluents);
        New_Certain_Fluents = Certain_Fluents
    ).
    

updateHasGold(left, _, Certain_Fluents, Certain_Fluents).
updateHasGold(right, _, Certain_Fluents, Certain_Fluents).
updateHasGold(forward, _, Certain_Fluents, Certain_Fluents).
updateHasGold(climb, _, Certain_Fluents, Certain_Fluents).
updateHasGold(shoot, _, Certain_Fluents, Certain_Fluents).