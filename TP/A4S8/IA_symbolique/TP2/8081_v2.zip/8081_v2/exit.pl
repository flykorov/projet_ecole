:- module(exit, [exit/5, remonter_chemin/2]).

:- use_module(pos).
:- use_module(adjacent).
	
trouver_adjacent([], _, _, _, _).
trouver_adjacent([X|Adjacents], Visited, Chasseur, Cells, Case) :-
	http_log('La valeur de Adjacents est : ~w\n', [Adjacents]),
	
	(member(X, Visited) ->
		delete(Visited, X, V),
		http_log('La valeur de X est : ~w\n', [X]),
		http_log('La valeur de V est : ~w\n', [V]),
		trouver_chemin(X, V, Chasseur, Cells, Case);
		http_log('Completion du else : ~w\n', [X])
	),
	http_log('La valeur de Visited est : ~w\n', [Visited]),
	trouver_adjacent(Adjacents, Visited, Chasseur, Cells, Case).

stop_chemin(X, X).
trouver_chemin(Depart, Visited, Chasseur, Cells, Case) :-
	adjacent(Cells, Depart, Adjacents),
	http_log('La valeur de Adjacents est : ~w\n', [Adjacents]),

	(member(Chasseur, Adjacents) ->
		http_log('La valeur de Depart est : ~w\n', [Depart]),
		stop_chemin(Depart, Case),
		http_log('La valeur de Case est : ~w\n', [Case]);
		trouver_adjacent(Adjacents, Visited, Chasseur, Cells, Case)
	).

exit(Sortie, Visited, Chasseur, Cells, Case) :-
	interface_visited_pos(Visited, Ls),
	http_log('La valeur de Ls est : ~w\n', [Ls]),

	trouver_chemin(Sortie, Ls, Chasseur, Cells, Case).

remonter_chemin([], _{x:1, y:1}).
remonter_chemin([_{from:X, to:_}|_], X).
